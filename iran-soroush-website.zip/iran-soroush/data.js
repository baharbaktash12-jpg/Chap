/* ==========================================================================
   data.js — لایه داده مشترک سایت چاپخانه ایران سروش
   همه‌ی متن‌ها، قیمت‌ها، تصاویر و تنظیمات اینجا در localStorage نگهداری می‌شوند
   تا از طریق پنل مدیریت (admin.html) قابل ویرایش باشند.
   ⚠️ توجه: چون این یک سایت کاملاً استاتیک (بدون سرور) است، داده‌ها فقط در
   همان مرورگر/دستگاهی ذخیره می‌شوند که ادمین با آن وارد شده. برای همگام‌سازی
   بین چند دستگاه، در آینده باید یک بک‌اند (مثل Node/PHP + دیتابیس) اضافه شود.
   ========================================================================== */

const STORAGE_KEY = "irsoroush_site_data_v1";
const AUTH_KEY = "irsoroush_admin_auth_v1";

const DEFAULT_DATA = {
  hero: {
    siteName: "چاپخانه ایران سروش",
    tagline: "کیفیت چاپ، امانت ما",
    equipments: [
      { icon: "🖨️", text: "مجهز به دستگاه دورنگ (دوورقی)" },
      { icon: "⚙️", text: "دستگاه جی‌تی‌او (GTO)" },
      { icon: "✂️", text: "برش لیزری دقیق" },
      { icon: "🔠", text: "چاپ لترپرس" }
    ]
  },
  contact: {
    phone: "09133100552",
    address: "خیابان تمدن",
    whatsapp: "https://wa.me/989133100552",
    telegram: "https://t.me/989133100552"
  },
  categories: [
    { id: "cat1", name: "پاکت",   price: 850000,  unit: "دسته ۱۰۰۰ عددی", image: "" },
    { id: "cat2", name: "سربرگ",  price: 620000,  unit: "دسته ۱۰۰۰ عددی", image: "" },
    { id: "cat3", name: "برچسب", price: 450000,  unit: "دسته ۱۰۰۰ عددی", image: "" },
    { id: "cat4", name: "پوستر", price: 25000,   unit: "هر برگ A3",     image: "" },
    { id: "cat5", name: "قبض",    price: 380000,  unit: "دسته ۱۰۰۰ عددی", image: "" },
    { id: "cat6", name: "فاکتور", price: 410000,  unit: "دسته ۱۰۰۰ عددی", image: "" },
    { id: "cat7", name: "تراکت", price: 320000,  unit: "دسته ۱۰۰۰ عددی", image: "" }
  ],
  faq: [
    { q: "چگونه سفارش خود را ثبت کنم؟", a: "از منوی «ثبت سفارش» دسته‌بندی موردنظر را انتخاب کرده و فایل طرح خود را آپلود کنید." },
    { q: "زمان تحویل سفارش چقدر است؟", a: "بسته به نوع کار، معمولاً بین ۱ تا ۳ روز کاری زمان می‌برد." },
    { q: "آیا امکان طراحی رایگان وجود دارد؟", a: "بله، تیم طراحی ما در صورت نیاز شما را راهنمایی می‌کند، برای هماهنگی با ما تماس بگیرید." }
  ]
};

/* ---- خواندن داده از localStorage (یا مقدار پیش‌فرض در اولین اجرا) ---- */
function loadSiteData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULT_DATA);
    const parsed = JSON.parse(raw);
    // اطمینان از وجود همه‌ی کلیدها حتی اگر نسخه قدیمی ذخیره شده باشد
    return Object.assign(structuredClone(DEFAULT_DATA), parsed);
  } catch (err) {
    console.error("خطا در خواندن داده‌ها، بازگشت به مقدار پیش‌فرض:", err);
    return structuredClone(DEFAULT_DATA);
  }
}

/* ---- ذخیره داده در localStorage ---- */
function saveSiteData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return true;
  } catch (err) {
    console.error("خطا در ذخیره‌سازی داده‌ها:", err);
    return false;
  }
}

/* ---- فرمت قیمت به تومان با جداکننده هزارگان ---- */
function formatPrice(num) {
  if (isNaN(num)) return "تماس بگیرید";
  return Number(num).toLocaleString("fa-IR") + " تومان";
}

/* ---- تولید شناسه یکتای ساده ---- */
function uid(prefix = "id") {
  return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
