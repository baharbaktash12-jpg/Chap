/* ==========================================================================
   auth.js — ورود ساده به پنل مدیریت
   ⚠️ توجه امنیتی: چون سایت بدون سرور/دیتابیس است، رمز عبور در همان مرورگر
   نگهداری می‌شود. این روش برای دمو و استفاده شخصی مناسب است، اما برای
   امنیت واقعی و حرفه‌ای (جلوگیری از دسترسی افراد فنی به رمز) پیشنهاد می‌شود
   در آینده یک بک‌اند واقعی (Node.js/PHP + دیتابیس) اضافه گردد.
   ========================================================================== */

const DEFAULT_ADMIN_PASSWORD = "admin123"; // رمز پیش‌فرض — پس از اولین ورود حتماً تغییر دهید
const PASS_KEY = "irsoroush_admin_pass_v1";
const SESSION_KEY = "irsoroush_admin_session_v1";

function getAdminPassword() {
  return localStorage.getItem(PASS_KEY) || DEFAULT_ADMIN_PASSWORD;
}

function setAdminPassword(newPass) {
  localStorage.setItem(PASS_KEY, newPass);
}

function checkAdminPassword(input) {
  return input === getAdminPassword();
}

function setAdminSession() {
  sessionStorage.setItem(SESSION_KEY, "1");
}

function isAdminLoggedIn() {
  return sessionStorage.getItem(SESSION_KEY) === "1";
}

function adminLogout() {
  sessionStorage.removeItem(SESSION_KEY);
}
