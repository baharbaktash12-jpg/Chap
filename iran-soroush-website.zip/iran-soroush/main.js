/* ==========================================================================
   main.js — منطق صفحه اصلی سایت (سمت کاربر)
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const data = loadSiteData();
  renderHero(data);
  renderContact(data);
  renderCategories(data);
  renderCategoryOptions(data);
  renderFAQ(data);
  bindNav();
  bindFAQToggle();
  bindSignupForm();
  bindPriceForm();
  bindOrderForm();
  bindTrackForm();
  bindFileDrop("orderFileInput", "orderFilePreview", "orderFileLabel");
});

/* ---------------- رندر بخش‌های دینامیک ---------------- */

function renderHero(data) {
  document.getElementById("brandTitle").textContent = data.hero.siteName;
  document.getElementById("footerBrand").textContent = data.hero.siteName;
  document.getElementById("heroTitle").textContent = data.hero.siteName;
  document.getElementById("heroTagline").textContent = data.hero.tagline;

  const grid = document.getElementById("equipGrid");
  grid.innerHTML = data.hero.equipments.map(eq => `
    <div class="equip-card">
      <span class="icon">${eq.icon || "🖨️"}</span>
      ${escapeHTML(eq.text)}
    </div>
  `).join("");
}

function renderContact(data) {
  document.getElementById("contactPhone").textContent = data.contact.phone;
  document.getElementById("contactPhoneLink").href = "tel:" + data.contact.phone;
  document.getElementById("contactAddress").textContent = data.contact.address;
  document.getElementById("waLink").href = data.contact.whatsapp;
  document.getElementById("tgLink").href = data.contact.telegram;
  document.getElementById("waFloat").href = data.contact.whatsapp;
  document.getElementById("tgFloat").href = data.contact.telegram;
}

function renderCategories(data) {
  const grid = document.getElementById("catGrid");
  grid.innerHTML = data.categories.map(cat => `
    <div class="cat-card">
      <div class="cat-img">
        ${cat.image ? `<img src="${cat.image}" alt="${escapeHTML(cat.name)}">` : "🖼️"}
      </div>
      <div class="cat-body">
        <h4>${escapeHTML(cat.name)}</h4>
        <div class="cat-unit">${escapeHTML(cat.unit || "")}</div>
        <div class="cat-price">${formatPrice(cat.price)}</div>
        <a href="#order" class="cat-order-btn" onclick="preselectCategory('${cat.id}')">ثبت سفارش</a>
      </div>
    </div>
  `).join("");
}

function renderCategoryOptions(data) {
  const selects = [document.getElementById("priceCategorySelect"), document.getElementById("orderCategorySelect")];
  selects.forEach(sel => {
    if (!sel) return;
    sel.innerHTML = data.categories.map(c => `<option value="${c.id}">${escapeHTML(c.name)}</option>`).join("");
  });
}

function renderFAQ(data) {
  const list = document.getElementById("faqList");
  list.innerHTML = data.faq.map((item, i) => `
    <div class="faq-item" data-index="${i}">
      <div class="faq-q">
        <span>${escapeHTML(item.q)}</span>
        <span class="arrow">▾</span>
      </div>
      <div class="faq-a">${escapeHTML(item.a)}</div>
    </div>
  `).join("");
}

/* ---------------- تعامل‌ها ---------------- */

function bindNav() {
  const burger = document.getElementById("burgerBtn");
  const nav = document.getElementById("navLinks");
  burger.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
}

function bindFAQToggle() {
  document.getElementById("faqList").addEventListener("click", (e) => {
    const item = e.target.closest(".faq-item");
    if (!item) return;
    item.classList.toggle("open");
  });
}

function preselectCategory(catId) {
  const sel = document.getElementById("orderCategorySelect");
  if (sel) sel.value = catId;
}

/* عمومی: تبدیل فایل انتخاب‌شده (از گالری موبایل یا کامپیوتر) به base64 برای پیش‌نمایش/ذخیره */
function bindFileDrop(inputId, previewId, labelId) {
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);
  const label = document.getElementById(labelId);
  if (!input) return;
  input.addEventListener("change", () => {
    const file = input.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      label.textContent = "لطفاً یک فایل تصویری انتخاب کنید";
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      preview.innerHTML = `<img src="${e.target.result}" alt="پیش‌نمایش فایل سفارش">`;
      input.dataset.base64 = e.target.result;
    };
    reader.readAsDataURL(file);
    label.textContent = "فایل انتخاب شد: " + file.name;
  });
}

/* ---------------- ثبت‌نام ---------------- */
function bindSignupForm() {
  const form = document.getElementById("signupForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("suName").value.trim();
    const phone = document.getElementById("suPhone").value.trim();
    const pass = document.getElementById("suPass").value;
    const msgBox = document.getElementById("signupMsg");

    if (!name || !phone || !pass) {
      showMsg(msgBox, "لطفاً همه فیلدها را پر کنید.", true);
      return;
    }
    const users = JSON.parse(localStorage.getItem("irsoroush_users") || "[]");
    if (users.some(u => u.phone === phone)) {
      showMsg(msgBox, "این شماره موبایل قبلاً ثبت‌نام کرده است.", true);
      return;
    }
    users.push({ name, phone, pass, createdAt: Date.now() });
    localStorage.setItem("irsoroush_users", JSON.stringify(users));
    showMsg(msgBox, "ثبت‌نام با موفقیت انجام شد. اکنون می‌توانید سفارش خود را ثبت کنید.", false);
    form.reset();
  });
}

/* ---------------- استعلام قیمت ---------------- */
function bindPriceForm() {
  const form = document.getElementById("priceForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = loadSiteData();
    const catId = document.getElementById("priceCategorySelect").value;
    const qty = document.getElementById("priceQty").value;
    const cat = data.categories.find(c => c.id === catId);
    const resultBox = document.getElementById("priceResult");
    if (!cat) return;
    const estimated = cat.price; // قیمت پایه؛ در پنل مدیریت قابل تغییر است
    resultBox.innerHTML = `
      <div class="msg msg-success">
        قیمت پایه برای «${escapeHTML(cat.name)}» (${escapeHTML(cat.unit)}): <b>${formatPrice(estimated)}</b><br>
        برای قیمت دقیق بر اساس تیراژ ${escapeHTML(qty || "")} با ما در تماس باشید: ${data.contact.phone}
      </div>`;
  });
}

/* ---------------- ثبت سفارش (آپلود فایل + گالری موبایل) ---------------- */
function bindOrderForm() {
  const form = document.getElementById("orderForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const msgBox = document.getElementById("orderMsg");
    const catId = document.getElementById("orderCategorySelect").value;
    const qty = document.getElementById("orderQty").value.trim();
    const phone = document.getElementById("orderPhone").value.trim();
    const fileInput = document.getElementById("orderFileInput");
    const fileData = fileInput.dataset.base64 || "";

    if (!phone || !qty) {
      showMsg(msgBox, "لطفاً شماره تماس و تیراژ را وارد کنید.", true);
      return;
    }
    const orders = JSON.parse(localStorage.getItem("irsoroush_orders") || "[]");
    const code = "IS-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    orders.push({
      code, catId, qty, phone,
      file: fileData,
      status: "در انتظار بررسی",
      createdAt: Date.now()
    });
    localStorage.setItem("irsoroush_orders", JSON.stringify(orders));
    showMsg(msgBox, `سفارش شما ثبت شد ✅ کد پیگیری شما: ${code} — این کد را برای پیگیری نزد خود نگه دارید.`, false);
    form.reset();
    document.getElementById("orderFilePreview").innerHTML = "";
    document.getElementById("orderFileLabel").textContent = "برای آپلود عکس از گالری موبایل یا کامپیوتر ضربه بزنید";
    delete fileInput.dataset.base64;
  });
}

/* ---------------- پیگیری سفارش ---------------- */
function bindTrackForm() {
  const form = document.getElementById("trackForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const code = document.getElementById("trackCode").value.trim().toUpperCase();
    const resultBox = document.getElementById("trackResult");
    const orders = JSON.parse(localStorage.getItem("irsoroush_orders") || "[]");
    const order = orders.find(o => o.code === code);
    if (!order) {
      resultBox.innerHTML = `<div class="msg msg-error">سفارشی با این کد پیدا نشد.</div>`;
      return;
    }
    const data = loadSiteData();
    const cat = data.categories.find(c => c.id === order.catId);
    resultBox.innerHTML = `
      <div class="msg msg-success">
        دسته‌بندی: ${escapeHTML(cat ? cat.name : "-")}<br>
        تیراژ: ${escapeHTML(order.qty)}<br>
        وضعیت سفارش: <b>${escapeHTML(order.status)}</b>
      </div>`;
  });
}

/* ---------------- ابزار کمکی ---------------- */
function showMsg(box, text, isError) {
  box.innerHTML = `<div class="msg ${isError ? "msg-error" : "msg-success"}">${escapeHTML(text)}</div>`;
}

function escapeHTML(str) {
  if (str === undefined || str === null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
