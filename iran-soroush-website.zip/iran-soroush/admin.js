/* ==========================================================================
   admin.js — منطق پنل مدیریت
   ========================================================================== */

let siteData = null;

document.addEventListener("DOMContentLoaded", () => {
  bindLogin();
  if (isAdminLoggedIn()) showDashboard();
});

/* ---------------- ورود ---------------- */
function bindLogin() {
  const form = document.getElementById("loginForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const pass = document.getElementById("loginPass").value;
    const msg = document.getElementById("loginMsg");
    if (checkAdminPassword(pass)) {
      setAdminSession();
      showDashboard();
    } else {
      msg.innerHTML = `<div class="msg msg-error">رمز عبور اشتباه است.</div>`;
    }
  });

  document.getElementById("logoutBtn").addEventListener("click", () => {
    adminLogout();
    location.reload();
  });
}

function showDashboard() {
  document.getElementById("loginScreen").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
  siteData = loadSiteData();
  renderHeroForm();
  renderCategoriesAdmin();
  renderFaqAdmin();
  renderContactForm();
  bindTabs();
  bindSaveHero();
  bindAddCategory();
  bindAddFaq();
  bindSaveContact();
  bindPasswordForm();
}

/* ---------------- تب‌ها ---------------- */
function bindTabs() {
  const tabs = document.querySelectorAll(".tab-btn");
  tabs.forEach(btn => {
    btn.addEventListener("click", () => {
      tabs.forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });
}

/* ---------------- بخش هیرو / تجهیزات ---------------- */
function renderHeroForm() {
  document.getElementById("heroSiteName").value = siteData.hero.siteName;
  document.getElementById("heroTagline").value = siteData.hero.tagline;
  renderEquipList();
}

function renderEquipList() {
  const wrap = document.getElementById("equipList");
  wrap.innerHTML = siteData.hero.equipments.map((eq, i) => `
    <div class="admin-row" data-index="${i}">
      <input type="text" class="eq-icon" value="${eq.icon || ""}" style="max-width:60px;text-align:center" placeholder="🖨️">
      <input type="text" class="eq-text" value="${escapeAttr(eq.text)}" placeholder="متن ویژگی">
      <button type="button" class="btn btn-danger btn-sm remove-eq">حذف</button>
    </div>
  `).join("");
  wrap.querySelectorAll(".remove-eq").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const idx = Number(e.target.closest(".admin-row").dataset.index);
      siteData.hero.equipments.splice(idx, 1);
      renderEquipList();
    });
  });
}

function bindSaveHero() {
  document.getElementById("addEquipBtn").addEventListener("click", () => {
    siteData.hero.equipments.push({ icon: "🖨️", text: "ویژگی جدید" });
    renderEquipList();
  });

  document.getElementById("heroForm").addEventListener("submit", (e) => {
    e.preventDefault();
    siteData.hero.siteName = document.getElementById("heroSiteName").value.trim();
    siteData.hero.tagline = document.getElementById("heroTagline").value.trim();

    document.querySelectorAll("#equipList .admin-row").forEach((row, i) => {
      siteData.hero.equipments[i].icon = row.querySelector(".eq-icon").value.trim();
      siteData.hero.equipments[i].text = row.querySelector(".eq-text").value.trim();
    });

    persist("heroMsg", "اطلاعات بنر و تجهیزات با موفقیت ذخیره شد.");
  });
}

/* ---------------- دسته‌بندی‌ها (محصولات) ---------------- */
function renderCategoriesAdmin() {
  const wrap = document.getElementById("catAdminList");
  wrap.innerHTML = siteData.categories.map((cat, i) => `
    <div class="cat-admin-card" data-index="${i}">
      <div class="cat-admin-img" data-index="${i}">
        ${cat.image ? `<img src="${cat.image}">` : `<span>🖼️ بدون تصویر</span>`}
        <label class="btn btn-outline btn-sm upload-label">
          تغییر تصویر
          <input type="file" accept="image/*" class="cat-image-input" style="display:none">
        </label>
      </div>
      <div class="cat-admin-fields">
        <div class="form-row"><label>نام دسته</label><input type="text" class="cat-name" value="${escapeAttr(cat.name)}"></div>
        <div class="form-row"><label>واحد / توضیح</label><input type="text" class="cat-unit" value="${escapeAttr(cat.unit)}"></div>
        <div class="form-row"><label>قیمت (تومان)</label><input type="number" class="cat-price" value="${cat.price}"></div>
        <div style="display:flex; gap:10px;">
          <button type="button" class="btn btn-sm save-cat">ذخیره این ردیف</button>
          <button type="button" class="btn btn-danger btn-sm remove-cat">حذف دسته</button>
        </div>
      </div>
    </div>
  `).join("");

  wrap.querySelectorAll(".cat-image-input").forEach(input => {
    input.addEventListener("change", (e) => {
      const idx = Number(e.target.closest(".cat-admin-card").dataset.index);
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        siteData.categories[idx].image = ev.target.result;
        saveSiteData(siteData);
        renderCategoriesAdmin();
      };
      reader.readAsDataURL(file);
    });
  });

  wrap.querySelectorAll(".save-cat").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const card = e.target.closest(".cat-admin-card");
      const idx = Number(card.dataset.index);
      siteData.categories[idx].name = card.querySelector(".cat-name").value.trim();
      siteData.categories[idx].unit = card.querySelector(".cat-unit").value.trim();
      siteData.categories[idx].price = Number(card.querySelector(".cat-price").value) || 0;
      persist("catMsg", `دسته «${siteData.categories[idx].name}» ذخیره شد.`);
    });
  });

  wrap.querySelectorAll(".remove-cat").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const idx = Number(e.target.closest(".cat-admin-card").dataset.index);
      if (!confirm("آیا از حذف این دسته مطمئن هستید؟")) return;
      siteData.categories.splice(idx, 1);
      persist("catMsg", "دسته حذف شد.");
      renderCategoriesAdmin();
    });
  });
}

function bindAddCategory() {
  document.getElementById("addCatBtn").addEventListener("click", () => {
    siteData.categories.push({ id: uid("cat"), name: "دسته جدید", price: 0, unit: "", image: "" });
    persist("catMsg", "دسته جدید اضافه شد، اطلاعات آن را تکمیل کنید.");
    renderCategoriesAdmin();
  });
}

/* ---------------- سوالات متداول ---------------- */
function renderFaqAdmin() {
  const wrap = document.getElementById("faqAdminList");
  wrap.innerHTML = siteData.faq.map((item, i) => `
    <div class="admin-row-col" data-index="${i}">
      <div class="form-row"><label>سوال</label><input type="text" class="faq-q-input" value="${escapeAttr(item.q)}"></div>
      <div class="form-row"><label>پاسخ</label><textarea rows="2" class="faq-a-input">${escapeAttr(item.a)}</textarea></div>
      <div style="display:flex; gap:10px;">
        <button type="button" class="btn btn-sm save-faq">ذخیره</button>
        <button type="button" class="btn btn-danger btn-sm remove-faq">حذف</button>
      </div>
      <hr>
    </div>
  `).join("");

  wrap.querySelectorAll(".save-faq").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const row = e.target.closest(".admin-row-col");
      const idx = Number(row.dataset.index);
      siteData.faq[idx].q = row.querySelector(".faq-q-input").value.trim();
      siteData.faq[idx].a = row.querySelector(".faq-a-input").value.trim();
      persist("faqMsg", "سوال ذخیره شد.");
    });
  });

  wrap.querySelectorAll(".remove-faq").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const idx = Number(e.target.closest(".admin-row-col").dataset.index);
      siteData.faq.splice(idx, 1);
      persist("faqMsg", "سوال حذف شد.");
      renderFaqAdmin();
    });
  });
}

function bindAddFaq() {
  document.getElementById("addFaqBtn").addEventListener("click", () => {
    siteData.faq.push({ q: "سوال جدید", a: "پاسخ را اینجا بنویسید." });
    renderFaqAdmin();
  });
}

/* ---------------- اطلاعات تماس ---------------- */
function renderContactForm() {
  document.getElementById("cPhone").value = siteData.contact.phone;
  document.getElementById("cAddress").value = siteData.contact.address;
  document.getElementById("cWhatsapp").value = siteData.contact.whatsapp;
  document.getElementById("cTelegram").value = siteData.contact.telegram;
}

function bindSaveContact() {
  document.getElementById("contactForm").addEventListener("submit", (e) => {
    e.preventDefault();
    siteData.contact.phone = document.getElementById("cPhone").value.trim();
    siteData.contact.address = document.getElementById("cAddress").value.trim();
    siteData.contact.whatsapp = document.getElementById("cWhatsapp").value.trim();
    siteData.contact.telegram = document.getElementById("cTelegram").value.trim();
    persist("contactMsg", "اطلاعات تماس ذخیره شد.");
  });
}

/* ---------------- تغییر رمز عبور ---------------- */
function bindPasswordForm() {
  document.getElementById("passForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const current = document.getElementById("curPass").value;
    const next = document.getElementById("newPass").value;
    const msg = document.getElementById("passMsg");
    if (!checkAdminPassword(current)) {
      msg.innerHTML = `<div class="msg msg-error">رمز فعلی اشتباه است.</div>`;
      return;
    }
    if (next.length < 4) {
      msg.innerHTML = `<div class="msg msg-error">رمز جدید باید حداقل ۴ کاراکتر باشد.</div>`;
      return;
    }
    setAdminPassword(next);
    msg.innerHTML = `<div class="msg msg-success">رمز عبور با موفقیت تغییر کرد.</div>`;
    document.getElementById("passForm").reset();
  });
}

/* ---------------- ابزار کمکی ---------------- */
function persist(msgId, successText) {
  const ok = saveSiteData(siteData);
  const box = document.getElementById(msgId);
  if (box) {
    box.innerHTML = ok
      ? `<div class="msg msg-success">${successText}</div>`
      : `<div class="msg msg-error">خطا در ذخیره‌سازی اطلاعات.</div>`;
  }
}

function escapeAttr(str) {
  if (str === undefined || str === null) return "";
  return String(str).replace(/"/g, "&quot;");
}
